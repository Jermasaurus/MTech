/**
 * @author Jerry Sommerfeld
 * CS1122 Spring 2014 - R02
 * Program #2
 */

package mstandem;

/**
 * This Class defines the HumanSoldier and extends the class CombatUnit.
 */
public class HumanSoldier extends CombatUnit {

	private double physicalFitness;
	private String placeOfBirth;
	private String rank;
	private double rationRequirements;
	
	/**
	 * This method is the main constructor for the HumanSoldier Class.
	 * 
	 * @param ammunitionIn -> int value for the amount of ammunition.
	 * @param armsSupplierIn -> String value for the arms supplier.
	 * @param weaponsIn -> String value for the weapons.
	 * @param physicalFitnessIn -> double value for the physical fitness of the soldier.
	 * @param placeOfBirthIn -> String value for the place where the soldier was born.
	 * @param rankIn -> String value for the rank of the soldier.
	 * @param rationRequirementsIn -> double value for the ration requirements of the soldier.
	 */
	public HumanSoldier(int ammunitionIn, String armsSupplierIn, String weaponsIn,
			double physicalFitnessIn, String placeOfBirthIn,
			String rankIn, double rationRequirementsIn)
	{
		setAmmunition(ammunitionIn);
		setArmsSupplier(armsSupplierIn);
		setPhysicalFitness(physicalFitnessIn);
		setPlaceOfBirth(placeOfBirthIn);
		setRank(rankIn);
		setRationRequirements(rationRequirementsIn);
		setWeapons(weaponsIn);
	}
	
	/**
	 * This method prints out an angsty message from the soldier.
	 */
	public void angst() {
		System.out.println("Soldier says, 'What am I fighting for?'");
	}
	
	/**
	 * This method is a getter for the physicalFitness variable.
	 * @return -> the double value of physicalFitness
	 */
	public double getPhysicalFitness() {
		return physicalFitness;
	}
	
	/**
	 * This method sets a new value for physicalFitness.
	 * @param physicalFitnessIn -> the new double value for physicalFitness
	 */
	public void setPhysicalFitness(double physicalFitnessIn) {
		physicalFitness = physicalFitnessIn;
	}
	
	/**
	 * This method is a getter for the placeOfBirth variable.
	 * @return -> the String value of placeOfBirth.
	 */
	public String getPlaceOfBirth() {
		return placeOfBirth;
	}
	
	/**
	 * This method sets a new value for placeOfBirth.
	 * @param placeOfBirthIn -> the new String value for placeOfBirth.
	 */
	public void setPlaceOfBirth(String placeOfBirthIn) {
		placeOfBirth = placeOfBirthIn;
	}
	
	/**
	 * This method is a getter for the rank variable.
	 * @return -> the String value of rank.
	 */
	public String getRank() {
		return rank;
	}
	
	/**
	 * This method sets a new value for rank.
	 * @param rankIn -> the new String value for rank.
	 */
	public void setRank(String rankIn) {
		rank = rankIn;
	}
	
	/**
	 * This method is a getter for the rationRequirements variable.
	 * @return -> the double value of rationRequirements.
	 */
	public double getRationRequirements() {
		return rationRequirements;
	}
	
	/**
	 * This method sets a new value for rationRequirements.
	 * @param rationRequirementsIn -> the new double value for rationRequirements.
	 */
	public void setRationRequirements(double rationRequirementsIn) {
		rationRequirements = rationRequirementsIn;
	}
	
	/**
	 * This method calculates the monthly maintenance cost of the soldier and returns it.
	 * @return -> the double value of the monthly maintenance cost of the soldier.
	 */
	public double monthlyMaintenanceCost() {
		return getRationRequirements() * 100.0;
	}
	
}
