/**
 * @author Jerry Sommerfeld
 * CS1122 Spring 2014 - R02
 * Program #2
 */

package mstandem;

/**
 * This class defines the Unmanned vehicle and extends the vehicle class.
 */
public class Unmanned extends Vehicle {
	
	private String autonomousProgram;
	
	/**
	 * This method is the main constructor for the Unmanned vehicle class.
	 * 
	 * @param ammunitionIn -> int value for the amount of ammunition.
	 * @param armsSupplierIn -> String value for the arms supplier.
	 * @param weaponsIn -> String value for the weapons.
	 * @param armorPlatingIn -> double value for the armor plating.
	 * @param fuelIn -> double value for the amount of fuel.
	 * @param manufacturerIn -> String value for the manufacturer.
	 * @param autonomousProgramIn -> String value for the name of the autonomous program.
	 */
	public Unmanned(int ammunitionIn, String armsSupplierIn, String weaponsIn,
			double armorPlatingIn, double fuelIn, String manufacturerIn,
			String autonomousProgramIn)
	{
		setAmmunition(ammunitionIn);
		setArmorPlating(armorPlatingIn);
		setArmsSupplier(armsSupplierIn);
		setAutonomousProgram(autonomousProgramIn);
		setFuel(fuelIn);
		setManufacturer(manufacturerIn);
		setWeapons(weaponsIn);
	}
	
	/**
	 * This method is a getter for the autonomousProgram variable.
	 * @return -> the String value of autonomousProgram.
	 */
	public String getAutonomousProgram() {
		return autonomousProgram;
	}

	/**
	 * This method sets a new value for autonomousProgram.
	 * @param autonomousProgramIn -> the new String variable for autonomous program.
	 */
	public void setAutonomousProgram(String autonomousProgramIn) {
		autonomousProgram = autonomousProgramIn;
	}
	
	/**
	 * This method scrambles the autonomous program so it cannot be copied
	 * and auto-destructs the unmanned vehicle.  It also prints out a special message
	 * for the enemy.
	 */
	public void selfDestruct() {
		setAutonomousProgram("MY COMRADES WILL AVENGE ME");
		setArmorPlating(0);
	}

}
