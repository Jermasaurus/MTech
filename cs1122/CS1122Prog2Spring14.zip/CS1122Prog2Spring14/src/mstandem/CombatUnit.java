/**
 * @author Jerry Sommerfeld
 * CS1122 Spring 2014 - R02
 * Program #2
 */

package mstandem;

/**
 * This class is the main class that all the other classes in the hierarchy extend.
 * It contains the most basic variables that all the other classes use as well.
 */
public abstract class CombatUnit {

	protected int ammunition;
	protected String weapons;
	protected String armsSupplier;
	
	/**
	 * This is the basic constructor for the CombatUnit class and subclasses.  
	 * It is empty because it is in an abstract class and cannot be instantiated.
	 */
	public CombatUnit() {
	}

	/**
	 * This method is a getter for the ammunition variable.
	 * @return -> the int value of ammunition.
	 */
	public int getAmmunition() {
		return ammunition;
	}

	/**
	 * This method sets the value for ammunition based on the ammunitionIn parameter.
	 * @param ammunitionIn -> the new value for ammunition.
	 */
	public void setAmmunition(int ammunitionIn) {
		ammunition = ammunitionIn;
	}
	
	/**
	 * This method is a getter for the weapons variable.
	 * @return -> the String value of weapons.
	 */
	public String getWeapons() {
		return weapons;
	}
	
	/**
	 * This method sets the String value for weapons based on the weaponsIn parameter.
	 * @param weaponsIn -> the new String value for weapons.
	 */
	public void setWeapons(String weaponsIn) {
		weapons = weaponsIn;
	}
	
	/**
	 * This method is a getter for the armsSupplier variable.
	 * @return -> the String value of armsSupplier.
	 */
	public String getArmsSupplier() {
		return armsSupplier;
	}
	
	/**
	 * This method sets the String value for armsSupplier based on the armsSupplierIn parameter.
	 * @param armsSupplierIn -> the new String value for armsSupplier.
	 */
	public void setArmsSupplier(String armsSupplierIn) {
		armsSupplier = armsSupplierIn;
	}
}
