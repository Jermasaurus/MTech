/**
 * @author Jerry Sommerfeld
 * CS1122 Spring 2014 - R02
 * Program #2
 */

package mstandem;

/**
 * This class defines the Motorized Suit and extends the Manned class.
 */
public class MotorizedSuit extends Manned {

	private boolean isPrototype;
	private double pilotSkill;
	
	/**
	 * This method is the constructor for the MotorizedSuit class.
	 * 
	 * @param ammunitionIn -> int value for the amount of ammunition.
	 * @param armsSupplierIn -> String value for the arms supplier.
	 * @param weaponsIn -> String value for the weapons.
	 * @param armorPlatingIn -> double value for the armor plating.
	 * @param fuelIn -> double value for the amount of fuel.
	 * @param manufacturerIn -> String value for the manufacturer.
	 * @param numberOfCrewIn -> int value for the number of crew in the vehicle.
	 * @param isPrototypeIn -> bool value to determine if the vehicle is a prototype or not.
	 * @param pilotSkillIn -> double value for the pilot's skill.
	 */
	public MotorizedSuit(int ammunitionIn, String armsSupplierIn, String weaponsIn,
			double armorPlatingIn, double fuelIn, String manufacturerIn,
			int numberOfCrewIn, boolean isPrototypeIn, double pilotSkillIn)
	{
		setAmmunition(ammunitionIn);
		setArmsSupplier(armsSupplierIn);
		setWeapons(weaponsIn);
		setArmorPlating(armorPlatingIn);
		setFuel(fuelIn);
		setManufacturer(manufacturerIn);
		setNumberOfCrew(numberOfCrewIn);
		setIsPrototype(isPrototypeIn);
		setPilotSkill(pilotSkillIn);
	}

	/**
	 * This method is a getter for the isPrototype variable.
	 * @return -> the bool value of isPrototype.
	 */
	public boolean getIsPrototype() {
		return isPrototype;
	}

	/**
	 * This method sets a new value for isPrototype.
	 * @param isPrototypeIn -> the new bool value of isPrototype.
	 */
	public void setIsPrototype(boolean isPrototypeIn) {
		isPrototype = isPrototypeIn;
	}

	/**
	 * This method is a getter for the pilotSkill variable.
	 * @return -> the double value of pilotSkill.
	 */
	public double getPilotSkill() {
		return pilotSkill;
	}

	/**
	 * This method sets a new value for pilotSkill.
	 * @param pilotSkillIn -> the new double value of pilotSkill. 
	 */
	public void setPilotSkill(double pilotSkillIn) {
		pilotSkill = pilotSkillIn;
	}
	
	/**
	 * This method sets a self-destruct sequence for the motorized suit.
	 */
	public void bailOut() {
		setNumberOfCrew(0);
		setArmorPlating(0);
	}
	
}
