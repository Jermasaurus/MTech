/**
 * @author Jerry Sommerfeld
 * CS1122 Spring 2014 - R02
 * Program #2
 */

package mstandem;

/**
 * This class defines the Vehicle and extends the class CombatUnit.
 */
public abstract class Vehicle extends CombatUnit {
	
	protected double armorPlating;
	protected double fuel;
	protected String manufacturer;
	
	/**
	 * This is the constructor for the Vehicle class and its subclasses.
	 * It is empty because it is in an abstract class and cannot be instantiated.
	 */
	public Vehicle() {
	}
	
	/**
	 * This method is a getter for the armorPlating variable.
	 * @return -> the double value of armorPlating.
	 */
	public double getArmorPlating() {
		return armorPlating;
	}

	/**
	 * This method sets a new value for armorPlating.
	 * @param armorPlatingIn -> the new double value for armorPlating.
	 */
	public void setArmorPlating(double armorPlatingIn) {
		armorPlating = armorPlatingIn;
	}
	
	/**
	 * This method is a getter for the fuel variable.
	 * @return -> the double value of fuel.
	 */
	public double getFuel() {
		return fuel;
	}

	/**
	 * This method sets a new value for fuel.
	 * @param fuelIn -> the new double value for fuel.
	 */
	public void setFuel(double fuelIn) {
		fuel = fuelIn;
	}

	/**
	 * This method is a getter for the manufacturer variable.
	 * @return -> the String value for manufacturer.
	 */
	public String getManufacturer() {
		return manufacturer;
	}

	/**
	 * This method sets a new value for manufacturer.
	 * @param manufacturerIn -> the new String value for manufacturer.
	 */
	public void setManufacturer(String manufacturerIn) {
		manufacturer = manufacturerIn;
	}
	
	/**
	 * This method calculates the monthly maintenance cost of the vehicle and returns it.
	 * @return -> the calculated monthly maintenance cost.
	 */
	public double monthlyMaintenanceCost() {
		return (100.0 - getFuel()) * 10000.0;
	}
	
	/**
	 * This method prints out sounds that all vehicles make.
	 */
	public void revEngine() {
		System.out.println("Vroom vroom");
	}

}
