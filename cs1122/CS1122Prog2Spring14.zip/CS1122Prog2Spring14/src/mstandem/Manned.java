/**
 * @author Jerry Sommerfeld
 * CS1122 Spring 2014 - R02
 * Program #2
 */

package mstandem;

/**
 * This class defines the Manned vehicle and extends the vehicle class.
 */
public class Manned extends Vehicle {
	
	protected int numberOfCrew;
	
	/**
	 * This method is the main constructor for the manned vehicle class.
	 * 
	 * @param ammunitionIn -> int value for the amount of ammunition.
	 * @param armsSupplierIn -> String value for the arms supplier.
	 * @param weaponsIn -> String value for the weapons.
	 * @param armorPlatingIn -> double value for the armor plating.
	 * @param fuelIn -> double value for the amount of fuel.
	 * @param manufacturerIn -> String value for the manufacturer.
	 * @param numberOfCrewIn -> int value for the number of crew in the vehicle.
	 */
	public Manned(int ammunitionIn, String armsSupplierIn, String weaponsIn,
			double armorPlatingIn, double fuelIn, String manufacturerIn,
			int numberOfCrewIn)
	{
		setAmmunition(ammunitionIn);
		setArmsSupplier(armsSupplierIn);
		setWeapons(weaponsIn);
		setArmorPlating(armorPlatingIn);
		setFuel(fuelIn);
		setManufacturer(manufacturerIn);
		setNumberOfCrew(numberOfCrewIn);
	}
	
	/**
	 * This method is a constructor used when the MotorizedSuit or other subclasses is instantiated.
	 */
	public Manned() {
	}
	
	/**
	 * This method is a getter for the numberOfCrew variable.
	 * @return -> the int value of numberOfCrew.
	 */
	public int getNumberOfCrew() {
		return numberOfCrew;
	}

	/**
	 * This method sets a new value for numberOfCrew.
	 * @param numberOfCrewIn -> the new int value for numberOfCrew. 
	 */
	public void setNumberOfCrew(int numberOfCrewIn) {
		numberOfCrew = numberOfCrewIn;
	}
	
	/**
	 * This method bails the crew out of the vehicle and destroys it.
	 */
	public void bailOut() {
		setNumberOfCrew(0);
		setArmorPlating(0);
	}

}
